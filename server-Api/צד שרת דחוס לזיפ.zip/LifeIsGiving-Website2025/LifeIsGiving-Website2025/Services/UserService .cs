﻿using LifeIsGiving_Website2025.Dtos;
using LifeIsGiving_Website2025.Dtos.LifeIsGiving_Website2025.Dtos;
using LifeIsGiving_Website2025.Interfaces;
using LifeIsGiving_Website2025.Models;
using LifeIsGiving_Website2025.Models.Enums;
using Microsoft.AspNetCore.Identity;

namespace LifeIsGiving_Website2025.Services
{
    public class UserService : IUserService
    {
        private readonly IUserRepository _userRepository;
        private readonly PasswordHasher<User> _passwordHasher;

        public UserService(IUserRepository userRepository)
        {
            _userRepository = userRepository;
            _passwordHasher = new PasswordHasher<User>();
        }

        public async Task AddUser(UserCreateDto userDto)
        {
            var user = new User
            {
                UserName = userDto.UserName,
                Name = userDto.Name,
                Email = userDto.Email,
                Phone = userDto.Phone,
                Address = userDto.Address,
                Role = userDto.Role
            };

            user.Password = _passwordHasher.HashPassword(user, userDto.Password);
            await _userRepository.AddUser(user);
        }

        public async Task<List<UserDto>> GetUsers()
        {
            var users = await _userRepository.GetUsers();

            return users.Select(u => new UserDto
            {
                UserName = u.UserName,
                Name = u.Name,
                Email = u.Email,
                Phone = u.Phone,
                Address = u.Address,
                Role = u.Role,

                Winnings = u.Winnings.Select(w => new WinningDto
                {
                    PrizeName = w.Prize.Name,
                    WinnerName = w.WinnerUser != null ? w.WinnerUser.Name : null,
                    LotteryDate = w.LotteryDate
                }).ToList(),

                Purchases = u.Purchases.Select(p => new PurchaseDto
                {
                    Id = p.Id,
                    UserName = p.User.Name,
                    PrizeName = p.Prize.Name,
                    PriceAtPurchase = p.PriceAtPurchase,
                    Quantity = p.Quantity,
                    Status = p.Status.ToString(),
                    CreatedAt = p.CreatedAt
                }).ToList()
            }).ToList();
        }


        public async Task<List<UserDto>> GetBuyers()
        {
            var buyers = await _userRepository.GetBuyers();

            return buyers.Select(u => new UserDto
            {
                UserName = u.UserName,
                Name = u.Name,
                Email = u.Email,
                Phone = u.Phone,
                Address = u.Address,
                Role = u.Role,

                Winnings = u.Winnings.Select(w => new WinningDto
                {
                    PrizeName = w.Prize.Name,
                    WinnerName = w.WinnerUser != null ? w.WinnerUser.Name : null,
                    LotteryDate = w.LotteryDate
                }).ToList(),

                Purchases = u.Purchases.Select(p => new PurchaseDto
                {
                    Id = p.Id,
                    UserName = p.User.Name,
                    PrizeName = p.Prize.Name,
                    PriceAtPurchase = p.PriceAtPurchase,
                    Quantity = p.Quantity,
                    Status = p.Status.ToString(),
                    CreatedAt = p.CreatedAt
                }).ToList()

            }).ToList();
        }
        public async Task<List<UserDonorDto>> GetDonors()
        {
            var donors = await _userRepository.GetDonors();

            return donors.Select(u => new UserDonorDto
            {
                UserName = u.UserName,
                Name = u.Name,
                Email = u.Email,
                Phone = u.Phone,
                Address = u.Address,
                Role = u.Role,
                PrizesDonated = u.PrizesDonated.Select(p => new PrizeDto
                {
                    Name = p.Name,
                    Description = p.Description,
                    Category = p.Category,
                    Price = p.Price,
                    ImageUrl = p.ImageUrl
                }).ToList()
            }).ToList();
        }

        public async Task<UserDto?> GetBuyerById(int id)
        {
            var user = await _userRepository.GetBuyerById(id);
            if (user == null) return null;

            return new UserDto
            {
                UserName = user.UserName,
                Name = user.Name,
                Email = user.Email,
                Phone = user.Phone,
                Address = user.Address,
                Role = user.Role,

                Winnings = user.Winnings.Select(w => new WinningDto
                {
                    PrizeName = w.Prize.Name,
                    WinnerName = w.WinnerUser != null ? w.WinnerUser.Name : null,
                    LotteryDate = w.LotteryDate
                }).ToList(),

                Purchases = user.Purchases.Select(p => new PurchaseDto
                {
                    Id = p.Id,
                    UserName = p.User.Name,
                    PrizeName = p.Prize.Name,
                    PriceAtPurchase = p.PriceAtPurchase,
                    Quantity = p.Quantity,
                    Status = p.Status.ToString(),
                    CreatedAt = p.CreatedAt
                }).ToList()
            };
        }

        public async Task<UserDonorDto?> GetDonorById(int id)
        {
            var user = await _userRepository.GetDonorById(id);
            if (user == null) return null;

            return new UserDonorDto
            {
                UserName = user.UserName,
                Name = user.Name,
                Email = user.Email,
                Phone = user.Phone,
                Address = user.Address,
                Role = user.Role,

                PrizesDonated = user.PrizesDonated.Select(p => new PrizeDto
                {
                    Name = p.Name,
                    Description = p.Description,
                    Category = p.Category,
                    Price = p.Price,
                    ImageUrl = p.ImageUrl
                }).ToList()
            };
        }





        public async Task<UserDto?> GetUserById(int id)
        {
            var user = await _userRepository.GetUserById(id);
            if (user == null) return null;

            return new UserDto
            {
                UserName = user.UserName,
                Name = user.Name,
                Email = user.Email,
                Phone = user.Phone,
                Address = user.Address,
                Role = user.Role,
            };
        }

        public async Task<List<User>> GetUsersByRole(UserRole role)
        {
            return await _userRepository.GetUsersByRole(role);
        }

        public async Task<bool> UpdateUser(int id, UserUpdateDto dto)
        {
            var user = await _userRepository.GetUserById(id);
            if (user == null) return false;

            user.UserName = dto.UserName ?? user.UserName;
            user.Name = dto.Name ?? user.Name;
            user.Email = dto.Email ?? user.Email;
            user.Phone = dto.Phone ?? user.Phone;
            user.Address = dto.Address ?? user.Address;
            user.Role = dto.Role ?? user.Role;

            return await _userRepository.UpdateUser(user);
        }

        public async Task<bool> DeleteUser(int id)
        {
            return await _userRepository.DeleteUser(id);
        }

        public async Task<List<UserDto>> GetBySort(string? name = null, string? email = null, string? prizeName = null)
        {
            var donors = await _userRepository.GetBySort(name, email, prizeName);
            return donors.Select(u => new UserDto
            {
                UserName = u.UserName,
                Name = u.Name,
                Email = u.Email,
                Phone = u.Phone,
                Address = u.Address,
                Role = u.Role,
            }).ToList();
        }

        public async Task<User?> GetUserByUserName(string userName)
        {
            return await _userRepository.GetUserByUserName(userName);
        }

    }
}
