﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace LifeIsGiving_Website2025.Migrations
{
    /// <inheritdoc />
    public partial class CheckIfAllfieldsCreated : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {

        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {

        }
    }
}
